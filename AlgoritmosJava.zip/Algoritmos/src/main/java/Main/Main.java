/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Algoritmos.Burbuja;
import Algoritmos.Respuesta;
import java.util.ArrayList;

/**
 *
 * @author Estudiantes
 */
public class Main {
    public static void main(String arg[]){
        Burbuja OrdenarBurbuja = new Burbuja();
        ArrayList<Integer> ListaNumeros = new ArrayList<>();
        for(int i=0;i<100;i++){
            ListaNumeros.add((int)(Math.random()*100));
        }
        Respuesta Respuesta = Burbuja.OrdenarBurbuja(ListaNumeros);
        System.out.println(Respuesta.getListaNumeros());
        System.out.println(Respuesta.getCiclos());
        System.out.println(Respuesta.getPasos());
    }
}
