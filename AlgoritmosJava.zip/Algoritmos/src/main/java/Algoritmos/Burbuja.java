/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algoritmos;

import java.util.ArrayList;

/**
 *
 * @author Estudiantes
 */
public class Burbuja {

    public static Respuesta OrdenarBurbuja(ArrayList<Integer> ListaNumeros) {
        int contador_pasos = 0;
        int contador_ciclos = 0;
        for (int i=0;i<ListaNumeros.size()-1;i++)  {
            for (int j=0;j<ListaNumeros.size()-1;j++)  {
                contador_ciclos += 1;
                if(ListaNumeros.get(j) > ListaNumeros.get(j+1)) {
                    int temp = ListaNumeros.get(j);
                    ListaNumeros.set(j, ListaNumeros.get(j+1));
                    ListaNumeros.set(j+1, temp);
                    contador_pasos += 3;
                }
                contador_pasos += 3;
            }
            contador_pasos += 4;
        }
        contador_pasos += 2;

        return new Respuesta(contador_pasos, contador_ciclos, ListaNumeros);
    }
}
