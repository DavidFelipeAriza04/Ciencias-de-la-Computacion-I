/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algoritmos;

import java.util.ArrayList;

/**
 *
 * @author Estudiantes
 */
public class Respuesta {

    private int Pasos;
    private int Ciclos;
    private ArrayList<Integer> ListaNumeros;

    public Respuesta(int Pasos, int Ciclos, ArrayList<Integer> ListaNumeros) {
        this.Pasos = Pasos;
        this.Ciclos = Ciclos;
        this.ListaNumeros = ListaNumeros;
    }

    public int getPasos() {
        return Pasos;
    }

    public int getCiclos() {
        return Ciclos;
    }

    public ArrayList<Integer> getListaNumeros() {
        return ListaNumeros;
    }

}
