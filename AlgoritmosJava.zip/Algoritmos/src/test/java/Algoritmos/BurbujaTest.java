/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Algoritmos;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Estudiantes
 */
public class BurbujaTest {
    
    public BurbujaTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of OredenarBurbuja method, of class Burbuja.
     */
    @Test
    public void testOredenarBurbuja() {
        System.out.println("OredenarBurbuja");
        ArrayList<Integer> ListaNumeros = ListaNumeros();
        Burbuja instance = new Burbuja();
        Respuesta result = instance.OrdenarBurbuja(ListaNumeros);
        Respuesta expResult = new Respuesta(result.getPasos(),(ListaNumeros.size()-1)^2,result.getListaNumeros());
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    private ArrayList<Integer> ListaNumeros(){
        ArrayList<Integer> ListaNumeros = new ArrayList<>();
        for(int i=0;i<100;i++){
            ListaNumeros.add((int)(Math.random()*100));
        }
        return ListaNumeros;
    }
    
}
